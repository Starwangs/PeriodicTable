
Current Version: R1

        Version log:

        ---Refactoring---

            1/6/2021 Version R1 14: Refactoring code and change from Python to Javascript, delete unnecessary function (Calculate more), add all element with API from neelpatel05
        
        ---BETA---

            30/1/2021 Version B8 12A: We have included more elements from number 44 to 48. Some grammar errors have been corrected
            29/1/2021 Version B7 12: We have included more elements from number 34 to 43.
            11/1/2021 Version B6 11: ANNOUNCEMENT: Our program data has lost. Good news! We have recovered the information until Version B3 form repl. We have rewriten the information about the element from number 26 to 33. 
            10/1/2021 Version B5 10: We have included more elements from number 31 to 33.
            9/1/2021 Version B4 9: We have included more elements from number 26 to 30.
            8/1/2021 Version B3 8: We have included more elements from number 21 to 25.
            7/1/2021 Version B2 7: We have included more elements form number 16 to 20'.
            6/1/2021 Version B1 6: Happy New Year 2021! We've opened the 1st version of the program. We have included more elements form number 7 to 15.

        ---Prototype---

            27/12/2020 Version P5 5: We've added more information about elements.
            26/12/2020 Version P4 4: REVISED VERSION ,this version has added 4 more modes in the calculator which are mass to volume ,volume to mass, mols to amount and amount to mols.
            We've checked grammar and edited some of the sentences also we change the word from mol to amount the mass of elements from atu to grams
            These make the program more revalant and easier to use. In amount summary we have added quantity to display more than mols.
            24/12/2020 Version P3 3: Gas mole calculation (Mode 2/2) and deleted old mode 2/1 because of its overlap feature with old mode 2/2, add more display output for clearer describtion
            We also have redesigned the mode 2 describtion and change some instruction to be easier to use ,we are working on mode 2/2 and 2/3. Some misspelled has reedited.
            23/12/2020 Version P2 2: Multiple elements calculation.
            22/12/2020 Version P1 1: Program structure ,mode 1-3 basic Element 1-6 calculator mode 1: single element calculation mass.
            This program is made for TU project by Pankwan,Aussadanisaorn,Chayanon and Sorrawit and refactoring by Chaiyapat.